package com.example.ProjectHans;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.projectzulaeha.R;

public class SianidaActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrollmovie);
    }
}